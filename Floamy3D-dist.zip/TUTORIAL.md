# Floamy3D — Authoring Tutorial

How to make **JEM armors**, **cosmetics**, and use the **`.jp`** transform language.

Pipeline in one line: geometry (JEM box model or Blockbench `.bbmodel`) → encoded into the resource pack → a vanilla entity shader ray-marches it on the player. Everything is server-side; players just accept the pack.

---

## 0. Folder layout (`plugins/Floamy3D/`)

```
config.yml
armors/<id>/        JEM armors          (config.yaml + layer_1/2.jem + layer_1/2.png)
cosmetics/<id>/     Blockbench cosmetics (config.yml + model.bbmodel + model.jp + textures/)
parsers/
  _*.jp             shared vars/rules (loaded first)
  armor/*.jp        transforms for armor parts
  cosmetic/*.jp     transforms for cosmetic (player) parts
  docs.md           full .jp reference
```

## Commands (`/f3d`, aliases `/forgery` `/forg`)
| command | effect |
|---|---|
| `/f3d build` | rebuild the pack from disk + re-send to everyone. **Use after editing any `.jp`/config** — no restart. |
| `/f3d wear <cosmeticId>` | wear a cosmetic (e.g. `cape_pride_cape`, `wings_default`). |
| `/f3d clear` | remove worn cosmetics. |
| `/f3d list` | list cosmetic ids. |
| `/f3d getArmor <id> <type>` | give an armor item. `type` = `modded` / `leather` / `vanilla` (or combos). |

Java/engine (shader) changes need a **server restart**; `.jp` and config changes only need `/f3d build`.

---

## 1. JEM armor

A JEM armor = a CEM box model (OptiFine `.jem`) for each armor layer + a flat texture, plus a `config.yaml`.

### `armors/<id>/config.yaml`
```yaml
enabled: true
versions:
  - "1_21_3"     # modern: entity/equipment/humanoid path
  - old          # legacy method
id: licorn:fenrir            # item id (namespace:path)

# MARKER COLORS — how the shader recognizes THIS armor. See "Reserved colors" below.
color:            { r: 255, g: 4,   b: 255 }   # outer marker (layer 1)
internal-color:   { r: 0,   g: 180, b: 0   }   # inner marker (layer 2)

glsl-variables:                # the per-part CEM ids this armor declares
  - LICORN_FENRIR_CHESTPLATE
  - LICORN_FENRIR_RIGHT_ARM
  - ... (one per part)

glsl-file: armor.glsl          # generated ray-march loop (leave as-is, rebuilt each /f3d build)
glsl-file-vsh: armor.glsl
vanilla_layer_1: layer_1.png   # the flat textures
vanilla_layer_2: layer_2.png

# To REPLACE a vanilla material's look instead of a custom item, set:
# vanilla_overrides: diamond   # (iron|gold|diamond|netherite|chainmail|leather)
```

### Layers / parts
- `layer_1.jem` = chestplate/boots slot → parts: `head` `body` `left_arm` `right_arm` `left_shoe` `right_shoe`
- `layer_2.jem` = leggings slot → parts: `waist` `body`(inner) `left_leg` `right_leg`
- The matching `.png` is the texture atlas for that layer.

Left/right is auto-detected by the shader (UV region + vertex parity) — author left and right parts separately; each renders on its correct limb.

### How it renders
On `/f3d build` the box geometry from the `.jem` is encoded into a data region of the leather atlas, and `armor.glsl` (auto-generated) ray-marches it. You don't hand-edit `armor.glsl`.

---

## 2. Reserved colors — DON'T collide with real armor

The shader recognizes an armor by a **per-vertex color id** (`(r<<16)+(g<<8)+b`). If you pick a `color:` / `internal-color:` that a player can *actually have* on real **dyed leather armor**, the plugin will hijack that real armor. **Avoid these:**

**Default (un-dyed) leather — the critical one:**
- `#A06540` = **(160, 101, 64)** — every default leather piece. Never use.

**The 16 dye base colors (avoid these and near-neighbors):**
| dye | hex | rgb |  | dye | hex | rgb |
|---|---|---|---|---|---|---|
| white | F9FFFE | 249,255,254 | | cyan | 169C9C | 22,156,156 |
| orange | F9801D | 249,128,29 | | purple | 8932B8 | 137,50,184 |
| magenta | C74EBD | 199,78,189 | | blue | 3C44AA | 60,68,170 |
| light_blue | 3AB3DA | 58,179,218 | | brown | 835432 | 131,84,50 |
| yellow | FED83D | 254,216,61 | | green | 5E7C16 | 94,124,22 |
| lime | 80C71F | 128,199,31 | | red | B02E26 | 176,46,38 |
| pink | F38BAA | 243,139,170 | | black | 1D1D21 | 29,29,33 |
| gray | 474F52 | 71,79,82 | | light_gray | 9D9D97 | 157,157,151 |

Leather can be **any** of ~5.7M dye blends, so the only fully safe markers are **highly saturated, "unnatural" colors** unlikely to come from dye mixing — e.g. pure `(255,4,255)` magenta-key or `(0,180,0)` green-key like the example. Pick bright primaries with one channel near 0 or 255 and you'll never collide.

---

## 3. Cosmetics (Blockbench)

A cosmetic = a `.bbmodel` authored on the player template + a `config.yml` + a `.jp`.

### `cosmetics/<id>/config.yml`
```yaml
id: cape
permission: floamy3d.cosmetic.cape
model: model.bbmodel
jp: model.jp
variants:                       # each variant = a texture; worn id is "<id>_<variant>"
  pride_cape: textures/pride_cape.png
```
Wear with `/f3d wear cape_pride_cape`.

### Authoring the model
- Build on the standard **player template** in Blockbench. Put extra cubes inside the vanilla bone group they should hang off (`body`, `head`, `right_arm`, …). Cubes outside every bone default to **body**.
- A cube inside a **named sub-group** rotates rigidly with that group (its `rotation` orbits the group origin; the cube's own rotation stays in place).

### Special bone-name conventions
- `e_<name>` group → cubes are **emissive** (full-bright). `e_<name>_e:0.5` sets intensity 0–1.
- `t_<name>` group → cubes are **transparent** (alpha 0.5 default). `t_<name>_t:0.3` sets alpha.

### `model.jp` (cosmetic transforms)
Same DSL as armor (see §4). Match key for a cosmetic is **`<id>:<bonePart>`**, e.g. `match cape:*` or `match cape:*body*`.

```jp
match cape:*
animate rot x radians(sin(gametime*500.0)*5.0)   # gentle sway
```

`animate <rot|pos|size> <x|y|z> <glsl-expr>` adds runtime GameTime animation (`gametime` → GameTime).

---

## 4. JavaPowder — the `.jp` transform language

**JavaPowder** is Floamy3D's transform DSL; scripts use the `.jp` extension. Hot-reloaded by `/f3d build`. Full reference is in `parsers/docs.md`. Cheat-sheet:

**Match** (`<id>:<part>`, globs, OR multiple):
```jp
match licorn_fenrir:*shoe*        # one armor's feet
match *:*body*                    # every body part
```

**Part-scope** (whole part): `translate x y z` · `rotate x|y|z deg` (orientation, in place) · `rotatesc x|y|z deg` (orbit positions around `scenepivot`) · `scenepivot x y z` · `scale e` · `sizeadd e` · `mirror` · `base PIX|none` · `bone STASIS_*` · `rotatechilds` / `rotatescchilds` (sub-bones only).

**Box-scope** (per cube, select with `cube <idx|*>`): `btranslate x y z` · `bset bz.x|y|z e` · `seat` · `flipu` / `flipv` / `flipupf` / `flipvpf` · `flipface <face> [u|v]` · `switchface <a> <b>` · `mirror x|y|z`.

**`rotate` vs `rotatesc`:** `rotate` spins orientation in place; `rotatesc` orbits the box *positions* around `scenepivot` (orientation untouched). For a rigid group rotation you usually want both, or set `scenepivot` to the body center so offset cubes fold instead of swinging away.

Vars + expr:
```jp
var LIFT 12
match *:*shoe*
cube *
btranslate 0 0 (0 - $LIFT)
```
Expr tokens: `t.x/y/z` (frame), `sz.*` (half-size), `bz.*` (box pos), `idx` (cube index), `$VAR`, `+ - * / ( )`.

See `parsers/docs.md` for the full op table, face names, and the transform pipeline order.
