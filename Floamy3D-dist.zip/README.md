# Floamy3D — Quick Start

3D armor + cosmetics for Paper/Spigot via vanilla entity shaders (CEM ray-march). No client mods.

## Run

1. Paper server **1.21.5+** (tested on 1.21.6 / 1.21.8 / 1.21.9 / 1.21.11). Older 1.20.5 / 1.21.2 overlays exist but cosmetics are armor-only there.
2. Copy `plugins/Floamy3D-2.0.0-dev.jar` **and** the `plugins/Floamy3D/` folder into your server's `plugins/`.
3. In `server.properties`, the plugin serves the resource pack over HTTP (default port `8085`). Make sure the client accepts server resource packs.
4. Start the server. On boot it builds the pack from `armors/`, `cosmetics/`, and `parsers/`.
5. Join and run:
   - `/f3d getArmor licorn_fenrir modded` — get the example armor.
   - `/f3d wear cape_pride_cape` — wear the example cape.
   - `/f3d build` — rebuild + re-send the pack after editing a `.jp` (no restart).

See **TUTORIAL.md** for authoring armors, cosmetics, and the `.jp` transform language.

## What's included
- `plugins/Floamy3D-2.0.0-dev.jar` — the plugin.
- `plugins/Floamy3D/armors/licorn_fenrir/` — full JEM armor example.
- `plugins/Floamy3D/cosmetics/cape/` — cape cosmetic (one variant: pride).
- `plugins/Floamy3D/parsers/` — the `.jp` transform scripts + `docs.md` reference.
